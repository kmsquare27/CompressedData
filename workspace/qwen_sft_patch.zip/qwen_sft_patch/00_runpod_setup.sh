#!/usr/bin/env bash
set -euo pipefail
# Run on a Linux x86-64 RunPod GPU with Python 3.11 and a CUDA-12.8-capable driver.
patch_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v python3.11 >/dev/null; then
  echo 'Python 3.11 is required. Select a RunPod PyTorch template with Python 3.11.' >&2
  exit 1
fi
python3.11 -m venv /workspace/sft-venv
/workspace/sft-venv/bin/python -m pip install 'pip==25.2'
/workspace/sft-venv/bin/python -m pip install 'torch==2.8.0' 'torchvision==0.23.0' --index-url https://download.pytorch.org/whl/cu128
/workspace/sft-venv/bin/python -m pip install -r "$patch_dir/requirements.txt"
/workspace/sft-venv/bin/python -m pip check
mkdir -p /workspace/sft_artifacts
/workspace/sft-venv/bin/python -m pip freeze > /workspace/sft_artifacts/environment.lock.txt
echo 'Setup complete. Run: source /workspace/sft-venv/bin/activate'
