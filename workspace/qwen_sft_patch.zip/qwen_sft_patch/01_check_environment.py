"""Run on RunPod before downloading/training. Exercises actual CUDA and NF4 backward."""
import argparse
import platform
import subprocess
import sys
from pathlib import Path
from sft_core import package_versions, write_json

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", required=True)
    args = p.parse_args()
    import torch
    import bitsandbytes as bnb
    from transformers import Qwen2_5_VLForConditionalGeneration, AutoProcessor
    from peft import LoraConfig, prepare_model_for_kbit_training
    assert sys.version_info[:2] == (3, 11), "Use the documented Python 3.11 environment"
    assert torch.cuda.is_available(), "CUDA unavailable; check NVIDIA driver and PyTorch CUDA wheel"
    assert torch.cuda.device_count() == 1, "Set CUDA_VISIBLE_DEVICES to exactly one GPU"
    assert torch.cuda.is_bf16_supported(), "This recipe requires a BF16-capable GPU"
    x = torch.randn(2, 32, device="cuda", dtype=torch.bfloat16, requires_grad=True)
    layer = bnb.nn.Linear4bit(32, 16, bias=False, compute_dtype=torch.bfloat16,
                             quant_type="nf4", compress_statistics=True).to("cuda")
    layer(x).float().square().mean().backward()
    assert x.grad is not None and torch.isfinite(x.grad).all(), "NF4 backward failed"
    props = torch.cuda.get_device_properties(0)
    result = {"python": sys.version, "platform": platform.platform(), "packages": package_versions(),
              "gpu": props.name, "vram_gib": props.total_memory/2**30,
              "compute_capability": [props.major, props.minor], "cuda_runtime": torch.version.cuda,
              "nf4_bf16_backward": "passed"}
    try:
        result["nvidia_smi"] = subprocess.check_output(["nvidia-smi"], text=True)
    except Exception as e:
        result["nvidia_smi_error"] = str(e)
    write_json(args.out, result)
    print(result["gpu"], round(result["vram_gib"], 1), "GiB; NF4/BF16 backward passed")
    if result["vram_gib"] < 23:
        print("Memory may be insufficient. The full-model smoke run, not this tiny check, determines feasibility.")

if __name__ == "__main__":
    main()
